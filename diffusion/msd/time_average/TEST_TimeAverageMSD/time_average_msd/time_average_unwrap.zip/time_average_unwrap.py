# trajectory should be unwrapped
import numpy as np
from ase.io import read
import time
import sys

method = sys.argv[1] 
path = sys.argv[2]
step = 10
atomic_number = 3   # Li for AIMD
atom_type = 1       # Li for MD

start_time = time.time()

if method == 'AIMD':

    # Read trajectory
    atoms_list = read(path, index='::'+str(step), format='vasp-xdatcar')
    N = len(atoms_list)

    positions = [atoms[atoms.get_atomic_numbers() == atomic_number].get_positions() for atoms in atoms_list]
    positions = np.array(positions)

    MSD = []
    for delt in range(1,N):
        # Calculate differences using broadcasting, resulting in an array with shape (N-delt, N_Li, 3)
        diffs = positions[delt:] - positions[:-delt]

        # Calculate squared distances
        squared_distances = np.sum(diffs**2, axis=-1)
        # Average over particles and time origins
        msd_avg = np.mean(squared_distances)
        # Standard deviation over particles and time origins
        msd_std = np.std(squared_distances)

        MSD.append((delt, msd_avg, msd_std))

    # Save MSD values
    with open('msd_avg_'+method, 'w') as f:
        for delt, msd, std in MSD:
            f.write(f"{delt * step} {msd:.5f} {std:.5f}\n")

    end_time = time.time()
    print(f"{end_time - start_time:.2f} seconds")

if method == 'MD':

    # Read trajectory
    atoms_list = read(path, index='::'+str(step), format='lammps-dump-text')
    N = len(atoms_list)

    positions = [atoms[atoms.numbers == atom_type].get_positions() for atoms in atoms_list]
    positions = np.array(positions)

    MSD = []
    for delt in range(1,N):
        # Calculate differences using broadcasting, resulting in an array with shape (N-delt, N_Li, 3)
        diffs = positions[delt:] - positions[:-delt]

        # Calculate squared distances
        squared_distances = np.sum(diffs**2, axis=-1)

        # Average over particles and time origins
        msd_avg = np.mean(squared_distances)
        # Standard deviation over particles and time origins
        msd_std = np.std(squared_distances)

        MSD.append((delt, msd_avg, msd_std))

    # Save MSD values
    with open('msd_avg_'+method, 'w') as f:
        for delt, msd, std in MSD:
            f.write(f"{delt * step} {msd:.5f} {std:.5f}\n")

    end_time = time.time()
    print(f"{end_time - start_time:.2f} seconds")
